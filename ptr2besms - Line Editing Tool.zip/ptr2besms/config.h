#ifndef BES_CONFIG_H
#define BES_CONFIG_H

/*
GAME_VERSION
  NTSC - Only supported version
  PAL - (not supported)
  NTSCJ - (not supported)
*/

//USING_WINDOWS doesn't change anything anymore atm
#define USING_WINDOWS

#define GAME_VERSION NTSC

#endif // BES_CONFIG_H
