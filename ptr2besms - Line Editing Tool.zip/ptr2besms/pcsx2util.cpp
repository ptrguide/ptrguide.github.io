#include "pcsx2util.h"
#include "pcsx2reader.h"

u32 findhdbase(u32 RESOURCE_LIST_BASE) {
    u32 caddr = RESOURCE_LIST_BASE;
    u32 raddr;
    u32 sig;
    int timeout = 20000; //NOTE: 20,000 resources is plenty

    do {
        pcsx2reader::read(
            caddr,
            &raddr,
            4
        );
        pcsx2reader::read(
            raddr,
            &sig,
            4
        );
        if(sig == HD_SIGNATURE) {
            return caddr;
        }
        caddr += 4;

    } while(timeout--);
    return 0;
}

int getnumhd(u32 hdbase) {
    u32 caddr = hdbase;
    u32 raddr;
    u32 sig;
    int count = 0;
    for(;;) {
        pcsx2reader::read(
            caddr,
            &raddr,
            4
        );
        caddr += 4;

        pcsx2reader::read(
            raddr,
            &sig,
            4
        );

        if(sig == HD_SIGNATURE) {
            count += 1;
        } else {
            return count;
        }
    }
}

u32 findbdbase(u32 RESOURCE_LIST_BASE) {
    u32 hdbase = findhdbase(RESOURCE_LIST_BASE);
    return hdbase + (getnumhd(hdbase) * 4);
}

u32 getvhbasefromhd(u32 hdbase) {
    return hdbase + 0x50; //FIXME: Assuming 0x50 offset
}

u32 getheadfromhd(u32 hdbase) {
    return hdbase + 0x10; //FIXME: Assuming 0x10 offset
}

u32 getsmplfromhd(u32 hdbase) {
    u32 vhbase = getvhbasefromhd(hdbase);
    u32 len;
        pcsx2reader::read(
            vhbase + 0x8,
            &len,
            4
        );

    return vhbase + len;
}

u32 getssetfromhd(u32 hdbase) {
    u32 smplbase = getsmplfromhd(hdbase);
    u32 len;
        pcsx2reader::read(
            smplbase + 0x8,
            &len,
            4
        );

    return smplbase + len;
}

u32 getprogfromhd(u32 hdbase) {
    u32 ssetbase = getssetfromhd(hdbase);
    u32 len;
        pcsx2reader::read(
            ssetbase + 0x8,
            &len,
            4
        );

    return ssetbase + len;
}

int installprograms(u32 hdbase, e_soundboard_t &sb) {
    sb.keys.clear();
    u32 numprograms;
    u32 smplbase = getsmplfromhd(hdbase);
    u32 ssetbase = getssetfromhd(hdbase);
    u32 progbase = getprogfromhd(hdbase);

    u32 smplindexbase = smplbase + 0x10;
    u32 ssetindexbase = ssetbase + 0x10;

    pcsx2reader::read(
        progbase + 0xC,
        &numprograms,
        4
    ); numprograms += 1;

    u32 pindexbase = progbase + 0x10;

    int i;
    for(i = 0; i < numprograms; i += 1) {
        u32 index;
        pcsx2reader::read(
            pindexbase + (i * 4),
            &index, 4
        );

        u32 progentrybase = progbase + index;
        u32 progentrylen;
        i8 numtokens;

        pcsx2reader::read(
            progentrybase,
            &progentrylen, 4
        );

        pcsx2reader::read(
            progentrybase + 4,
            &numtokens, 1
        );

        u32 progtokenbase = progentrybase + progentrylen;

        int k;
        for(k = 0; k < numtokens; k+=1) {
            u16 ssetindex;
            u32 ssetoffset;
            u16 smplindex;
            u32 smploffset;
            u16 bdindex;

            u8 keyid;

            pcsx2reader::read(
                progtokenbase + (k * 0x14), &ssetindex, 2
            );

            pcsx2reader::read(
                progtokenbase + (k * 0x14) + 2, &keyid, 1
            );

            pcsx2reader::read(
                ssetindexbase + (ssetindex * 4),
                &ssetoffset, 4
            );

            pcsx2reader::read(
                (ssetbase + ssetoffset) + 4,
                &smplindex, 2
            );

            pcsx2reader::read(
                smplindexbase + (smplindex * 4),
                &smploffset, 4
            );

            pcsx2reader::read(
                (smplbase + smploffset),
                &bdindex, 2
            );

            sb.prog[i][keyid] = bdindex;
        }
    }
	return sb.keys.size();
}

void pcsx2downloadkeytable(u32 keybase, int numkeys, e_soundboard_t &sb) {
    sb.keys.clear();
    sb.keys.resize(numkeys);

    int i;
    for(i = 0; i < numkeys; i += 1) {
        pcsx2reader::read(
            keybase + (6 * i),
            &sb.keys[i],
            6
        );
    }
}

void pcsx2downloadsoundboard(u32 hdbase, u32 bdbase, u32 keybase, int numkeys, e_soundboard_t &sb) {
    sb.clear();
    u32 head = getheadfromhd(hdbase);
    u32 vhbase = getvhbasefromhd(hdbase);
    u32 vhcount;
    u32 bdlen;
    e_sound_t vhentry;

    pcsx2reader::read(
        head + 0x10,
        &bdlen,
        4
    );

    sb.bd.len = bdlen;
    sb.bd.bytes = (byte*)(malloc(sb.bd.len));
    pcsx2reader::read(
        bdbase,
        sb.bd.bytes,
        sb.bd.len
    );


    pcsx2reader::read(
        vhbase + 0xC,
        &vhcount,
        4
    );

    vhcount += 1;

    u32 vhindices = vhbase + 0x10;
    u32 vhentries = vhindices + (vhcount * 4);

    sb.sounds.resize(vhcount);

    int i;
    for(i = 0; i < vhcount; i += 1) {
        u32 vhoffset;
        pcsx2reader::read(
            vhindices + (i * 4),
            &vhoffset,
            4
        );

        pcsx2reader::read(
            vhbase + vhoffset,
            &sb.sounds[i],
            8
        );
    }

    installprograms(hdbase, sb);

    if(keybase) {
        pcsx2downloadkeytable(
            keybase, numkeys, sb
        );
    }
}

void pcsx2downloadkeytables(u32 keylistbase, int count, int sbbase,
    std::vector<e_soundboard_t> &sblist
) {
    int i;
    u32 numkeys;
    u32 ptrkeytable;
    for(i = 0; i < count; i += 1) {
        u32 keylistentry = keylistbase + (i * 0x10);
        pcsx2reader::read(
            keylistentry + 0x8,
            &numkeys, 4
        );
        pcsx2reader::read(
            keylistentry + 0xC,
            &ptrkeytable, 4
        );
        pcsx2downloadkeytable(
            ptrkeytable, int(numkeys),
            sblist[sbbase + i]
        );
    }
}

void pcsx2downloadsoundboards(
    u32 hdlistbase, u32 bdlistbase, u32 count,
    std::vector<e_soundboard_t> &sblist
) {
    sblist.clear();
    int i;
    u32 hdbase;
    u32 bdbase;
    sblist.resize(count);
    for(i = 0; i < count; i += 1) {
        pcsx2reader::read(
            hdlistbase + (i * 4),
            &hdbase,
            4
        );

        pcsx2reader::read(
            bdlistbase + (i * 4),
            &bdbase,
            4
        );

        pcsx2downloadsoundboard(
            hdbase,
            bdbase,
            0,0,
            sblist[i]
        );
    }
}


void ps2linetoeditor(const suggestline_t &ps2, e_suggestline_t &editor) {
    editor.owner = ps2.owner;
    editor.buttons.clear();
    editor.buttons.resize(ps2.buttoncount);

    int i;
    for(i = 0; i < ps2.buttoncount; i += 1) {
        pcsx2reader::read(
            ps2.ptr_buttons + (sizeof(suggestbutton_t) * i),
            &editor.buttons[i],
            sizeof(suggestbutton_t)
        );
    }

    editor.coolmodethreshold = ps2.coolmodethreshold;
    editor.localisations[0] = nullptr;
    editor.localisations[1] = nullptr;
    editor.localisations[2] = nullptr;
    editor.localisations[3] = nullptr;
    editor.timestamp_start = ps2.timestamp_start;
    editor.timestamp_end = ps2.timestamp_end;
    editor.always_zero = 0;
}

void ps2varianttoeditor(const suggestvariant_t &ps2, e_suggestvariant_t &editor) {
    editor.lines.clear();
    editor.lines.resize(ps2.numlines);

    int i;
    suggestline_t ps2line;
    for(i = 0; i < ps2.numlines; i += 1) {
        pcsx2reader::read(
            ps2.ptr_lines + (sizeof(suggestline_t) * i),
            &ps2line,
            sizeof(ps2line)
        );
        ps2linetoeditor(ps2line, editor.lines[i]);
    }
}

void ps2recordtoeditor(const suggestrecord_t &ps2, e_suggestrecord_t &editor) {
    editor.lengthinsubdots = ps2.lengthinsubdots;
    editor.soundboardid = ps2.soundboardid;

    memcpy(editor.unk, ps2.unk, sizeof(editor.unk));

    suggestvariant_t ps2variant;
    int i; int k;
    u32 tmpptr[17]; //used to check variant links
    for(i = 0; i < 17; i += 1) {
        ps2varianttoeditor(ps2.variants[i], editor.variants[i]);
        editor.variants[i].islinked = false;
        editor.variants[i].linknum = -1;
    }

    for(i = 1; i < 17; i += 1) {
        for(k = 0; k < i; k += 1) {
            if(ps2.variants[i].ptr_lines == ps2.variants[k].ptr_lines) {
                editor.variants[i].islinked = true;
                editor.variants[i].linknum = k;
                k = i; //Termiante "k" loop
            }
        }
    }

}

void pcsx2downloadrecord(u32 record_addr, e_suggestrecord_t &editor_record) {
    suggestrecord_t ps2_record;

    pcsx2reader::read(record_addr, &ps2_record, sizeof(ps2_record));

    ps2recordtoeditor(ps2_record, editor_record);
}

int pcsx2downloadrecords(u32 stagecmd_start, int count, u32 type, std::vector<e_suggestrecord_t> &records) {
    u32 caddr = stagecmd_start;
    u32 lastrecord = 0;
    e_suggestrecord_t record;
    u32 raddr;
    int nrecords = 0;

    int i = 0;
    while(i < count) {
        u16 cmd;

        pcsx2reader::read(
            caddr,
            &cmd, 2
        );

        if(cmd == 0x1) {
            pcsx2reader::read(
                caddr + 0xC,
                &raddr, 4
            );

            if(
                (raddr >= 0x1000000) &&
                (raddr != lastrecord)
            ) {
                pcsx2downloadrecord(raddr, record);
                record.type = type;
                records.push_back(record);
                nrecords += 1;
                lastrecord = raddr;
            }
        } else if(cmd == 0x9) {
            u16 subcmd;
            pcsx2reader::read(
                caddr + 0x2,
                &subcmd, 2
            );
            if(subcmd == 0xE) { // Check for preload record command
                pcsx2reader::read(
                    caddr + 0x4,
                    &raddr, 4
                );
                if(
                    (raddr >= 0x1000000) &&
                    (raddr != lastrecord)
                ) {
                    pcsx2downloadrecord(raddr, record);
                    record.type = type;
                    records.push_back(record);
                    nrecords += 1;
                    lastrecord = raddr;
                }
            }
        }

        i += 1;
        caddr += 0x10;
    }
	return records.size();
}

int pcsx2downloadrecordsfrommodelist(u32 stagemode_start, std::vector<e_suggestrecord_t> &records) {
    int i;
    int acc = 0;
    scenemode_t modes[9];

    pcsx2reader::read(
        stagemode_start,
        modes, sizeof(modes)
    );

    for(i = 0; i < 9; i += 1) {
        if(i == 2 || i == 3) { continue; }
        acc += pcsx2downloadrecords(
            modes[i].ptr_scenecommands, modes[i].count_scenecommands,
            i,
            records
        );
    }

    return acc;
}

void pcsx2downloadcommandbuffers(u32 stagemode_start, std::vector<commandbuffer_t> *buffers) {
    scenemode_t modes[9];
    int i;
    pcsx2reader::read(
        stagemode_start, modes, sizeof(modes)
    );

    commandbuffer_t cb;

    for(i = 0; i < 9; i += 1) {
	    buffers[i].clear();
        for(int k = 0; k < modes[i].count_scenecommands; k += 1) {
            pcsx2reader::read(
                modes[i].ptr_scenecommands + (k * 0x10),
                cb.data, 16
            );
            buffers[i].push_back(cb);
        }
    }
}
