#include "suggest.h"

struct editor_t {
    std::vector<e_suggestrecord_t> records;
};
