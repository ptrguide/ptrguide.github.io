﻿namespace ptr2sound
{
	partial class Good
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button ProcessButton;
		private System.Windows.Forms.Button InputButton;
		private System.Windows.Forms.Button OutputButton;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.ComboBox StageCombo;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox RankCombo;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Button OutputButton2;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Button OutputButton3;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.ProcessButton = new System.Windows.Forms.Button();
			this.InputButton = new System.Windows.Forms.Button();
			this.OutputButton = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.StageCombo = new System.Windows.Forms.ComboBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.RankCombo = new System.Windows.Forms.ComboBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.OutputButton2 = new System.Windows.Forms.Button();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.OutputButton3 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// ProcessButton
			// 
			this.ProcessButton.Enabled = false;
			this.ProcessButton.Location = new System.Drawing.Point(13, 132);
			this.ProcessButton.Name = "ProcessButton";
			this.ProcessButton.Size = new System.Drawing.Size(373, 118);
			this.ProcessButton.TabIndex = 2;
			this.ProcessButton.Text = "Process";
			this.ProcessButton.UseVisualStyleBackColor = true;
			this.ProcessButton.Click += new System.EventHandler(this.ProcessButtonClick);
			// 
			// InputButton
			// 
			this.InputButton.Enabled = false;
			this.InputButton.Location = new System.Drawing.Point(13, 72);
			this.InputButton.Name = "InputButton";
			this.InputButton.Size = new System.Drawing.Size(122, 25);
			this.InputButton.TabIndex = 3;
			this.InputButton.Text = "Open WP2 or WAV";
			this.InputButton.UseVisualStyleBackColor = true;
			this.InputButton.Click += new System.EventHandler(this.InputButtonClick);
			// 
			// OutputButton
			// 
			this.OutputButton.Enabled = false;
			this.OutputButton.Location = new System.Drawing.Point(13, 103);
			this.OutputButton.Name = "OutputButton";
			this.OutputButton.Size = new System.Drawing.Size(122, 25);
			this.OutputButton.TabIndex = 4;
			this.OutputButton.Text = "Select Output";
			this.OutputButton.UseVisualStyleBackColor = true;
			this.OutputButton.Click += new System.EventHandler(this.OutputButtonClick);
			// 
			// textBox1
			// 
			this.textBox1.Enabled = false;
			this.textBox1.Location = new System.Drawing.Point(141, 75);
			this.textBox1.Name = "textBox1";
			this.textBox1.ReadOnly = true;
			this.textBox1.Size = new System.Drawing.Size(245, 20);
			this.textBox1.TabIndex = 6;
			// 
			// textBox2
			// 
			this.textBox2.Enabled = false;
			this.textBox2.Location = new System.Drawing.Point(141, 106);
			this.textBox2.Name = "textBox2";
			this.textBox2.ReadOnly = true;
			this.textBox2.Size = new System.Drawing.Size(245, 20);
			this.textBox2.TabIndex = 7;
			// 
			// StageCombo
			// 
			this.StageCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.StageCombo.FormattingEnabled = true;
			this.StageCombo.Items.AddRange(new object[] {
			"Stage 1",
			"Stage 2",
			"Stage 3",
			"Stage 4",
			"Stage 5",
			"Stage 6",
			"Stage 7",
			"Stage 8"});
			this.StageCombo.Location = new System.Drawing.Point(141, 12);
			this.StageCombo.Name = "StageCombo";
			this.StageCombo.Size = new System.Drawing.Size(245, 21);
			this.StageCombo.TabIndex = 8;
			this.StageCombo.SelectedIndexChanged += new System.EventHandler(this.StageComboSelectedIndexChanged);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 15);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(71, 21);
			this.label1.TabIndex = 9;
			this.label1.Text = "Select Stage:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(13, 45);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(70, 21);
			this.label2.TabIndex = 10;
			this.label2.Text = "Select Rank:";
			// 
			// RankCombo
			// 
			this.RankCombo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.RankCombo.Enabled = false;
			this.RankCombo.FormattingEnabled = true;
			this.RankCombo.Items.AddRange(new object[] {
			"Cool",
			"Good",
			"Bad+Awful"});
			this.RankCombo.Location = new System.Drawing.Point(141, 42);
			this.RankCombo.Name = "RankCombo";
			this.RankCombo.Size = new System.Drawing.Size(245, 21);
			this.RankCombo.TabIndex = 11;
			this.RankCombo.SelectedIndexChanged += new System.EventHandler(this.RankComboSelectedIndexChanged);
			// 
			// textBox3
			// 
			this.textBox3.Enabled = false;
			this.textBox3.Location = new System.Drawing.Point(141, 137);
			this.textBox3.Name = "textBox3";
			this.textBox3.ReadOnly = true;
			this.textBox3.Size = new System.Drawing.Size(245, 20);
			this.textBox3.TabIndex = 13;
			this.textBox3.Visible = false;
			// 
			// OutputButton2
			// 
			this.OutputButton2.Enabled = false;
			this.OutputButton2.Location = new System.Drawing.Point(13, 134);
			this.OutputButton2.Name = "OutputButton2";
			this.OutputButton2.Size = new System.Drawing.Size(123, 25);
			this.OutputButton2.TabIndex = 12;
			this.OutputButton2.Text = "Select Output";
			this.OutputButton2.UseVisualStyleBackColor = true;
			this.OutputButton2.Visible = false;
			this.OutputButton2.Click += new System.EventHandler(this.OutputButton2Click);
			// 
			// textBox4
			// 
			this.textBox4.Enabled = false;
			this.textBox4.Location = new System.Drawing.Point(141, 168);
			this.textBox4.Name = "textBox4";
			this.textBox4.ReadOnly = true;
			this.textBox4.Size = new System.Drawing.Size(245, 20);
			this.textBox4.TabIndex = 15;
			this.textBox4.Visible = false;
			// 
			// OutputButton3
			// 
			this.OutputButton3.Enabled = false;
			this.OutputButton3.Location = new System.Drawing.Point(13, 165);
			this.OutputButton3.Name = "OutputButton3";
			this.OutputButton3.Size = new System.Drawing.Size(123, 25);
			this.OutputButton3.TabIndex = 14;
			this.OutputButton3.Text = "Select Output";
			this.OutputButton3.UseVisualStyleBackColor = true;
			this.OutputButton3.Visible = false;
			this.OutputButton3.Click += new System.EventHandler(this.OutputButton3Click);
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(277, 256);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(118, 15);
			this.label3.TabIndex = 16;
			this.label3.Text = "ptr2sound v0.1 BETA";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(13, 256);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(203, 15);
			this.label4.TabIndex = 17;
			this.label4.Text = "by pips       https://discord.gg/xpvVnYd";
			// 
			// Good
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(400, 278);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.textBox4);
			this.Controls.Add(this.OutputButton3);
			this.Controls.Add(this.textBox3);
			this.Controls.Add(this.OutputButton2);
			this.Controls.Add(this.RankCombo);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.StageCombo);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.OutputButton);
			this.Controls.Add(this.InputButton);
			this.Controls.Add(this.ProcessButton);
			this.Name = "Good";
			this.Text = "ptr2sound";
			this.ResumeLayout(false);
			this.PerformLayout();

		}
	}
}
