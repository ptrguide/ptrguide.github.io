#include <inttypes.h>
#include <wchar.h>

typedef uint32_t u32;
typedef uint16_t u16;
typedef uint8_t byte;
typedef byte u8;
typedef int8_t i8;
typedef int16_t i16;
typedef int32_t i32;
