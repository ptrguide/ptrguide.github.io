#ifndef BES_BDUTIL_H
#define BES_BDUTIL_H

#include "types.h"

int getbdlen(byte *bd);
int getnsamplesfrombdlen(int len);

#endif

